package com.kvebiant.clima

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
